
/** EX 1 : */
document.getElementById("btnThreeNumber").onclick = function () {
  var a = parseFloat(document.getElementById("num1").value);
  var b = parseFloat(document.getElementById("num2").value);
  var c = parseFloat(document.getElementById("num3").value);
  var min;
  var med;
  var max;

  if (a > b && a > c) {
    if (b > c) {
      max = a;
      med = b;
      min = c;
    } else {
      max = a;
      med = c;
      min = b;
    }
  } else if (b > a && b > c) {
    if (a > c) {
      max = b;
      med = a;
      min = c;
    } else {
      max = b;
      med = c;
      min = a;
    }
  } else if (c > a && c > b) {
    if (a > b) {
      max = c;
      med = a;
      min = b;
    } else {
      max = c;
      med = b;
      min = a;
    }
  }

  document.getElementById("txtThreeNumberOutput").innerHTML =
    "Result : " + min + " -> " + med + " -> " + max;
};

/** EX 2: */
document.getElementById("memberList").addEventListener("click", function () {
  var familyMember = document.getElementById("memberList").value;

  switch (familyMember) {
    case "B":
      document.getElementById("txtWelcome").innerHTML = "Xin chào Ba!";
      break;
    case "M":
      document.getElementById("txtWelcome").innerHTML = "Xin chào Mẹ!";
      break;
    case "A":
      document.getElementById("txtWelcome").innerHTML = "Xin chào Anh trai!";
      break;
    case "E":
      document.getElementById("txtWelcome").innerHTML = "Xin chào Em gái!";
      break;
    case "O":
      document.getElementById("txtWelcome").innerHTML = "";
      break;
    default:
      console.log("Biết ai đâu mà chào !!!");
  }
});

/** EX 3: */
document.getElementById("btnOddEvenNumber").addEventListener("click", function () {
  var x = parseFloat(document.getElementById("number1").value);
  var y = parseFloat(document.getElementById("number2").value);
  var z = parseFloat(document.getElementById("number3").value);

  if (x % 2 == 0 && y % 2 == 0 && z % 2 == 0) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 3 số chẵn.';
  } else if (x % 2 == 1 && y % 2 == 1 && z % 2 == 1) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 3 số lẻ.';
  } else if (x % 2 == 0 && y % 2 == 0 && z % 2 == 1) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số chẵn và 1 số lẻ.';
  } else if (x % 2 == 1 && y % 2 == 0 && z % 2 == 0) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số chẵn và 1 số lẻ.';
  } else if (x % 2 == 0 && y % 2 == 1 && z % 2 == 0) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số chẵn và 1 số lẻ.';
  } else if (x % 2 == 1 && y % 2 == 1 && z % 2 == 0) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số lẻ và 1 số chẵn.';
  } else if (x % 2 == 0 && y % 2 == 1 && z % 2 == 1) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số lẻ và 1 số chẵn.';
  } else if (x % 2 == 1 && y % 2 == 0 && z % 2 == 1) {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Có 2 số lẻ và 1 số chẵn.';
  } else {
    document.getElementById("txtOddEvenNumber").innerHTML = 'Ko có số nào.';
  }
});

/** EX 4: */
document.getElementById("btnWhatTriangle").addEventListener("click", function () {
  var e1 = parseFloat(document.getElementById("edge1").value);
  var e2 = parseFloat(document.getElementById("edge2").value);
  var e3 = parseFloat(document.getElementById("edge3").value);

  if (e1 == e2 && e1 == e3 && e2 == e3) {
    document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác đều';
  } else if (e1 == Math.sqrt(e2 * e2 + e3 * e3)) {
    document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác vuông';
  } else if (e2 == Math.sqrt(e1 * e1 + e3 * e3)) {
    document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác vuông';
  } else if (e3 == Math.sqrt(e1 * e1 + e2 * e2)) {
    document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác vuông';
  } else if (e1 == e2 || e1 == e3 || e2 == e3) {
    document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác cân';
  } else { document.getElementById("txtWhatTriangle").innerHTML = 'Result : Tam giác thường'; }
})





