document.getElementById("btnTinhLuong").onclick = (event) => {
    event.preventDefault();
    let staff = {};
    let salaryFactor = Number(document.querySelector("#chonChucVu").value);
    document.getElementById("heSoLuong").innerHTML = salaryFactor;// Xuất ra U.I
    let arrInput = document.querySelectorAll("form input, select");
    let rowContent = `<p>`;
    for (let i = 0; i < arrInput.length; i++) {
        let tagInput = arrInput[i];
        let { id, value } = tagInput;
        staff = { ...staff, [id]: value };
        rowContent += `<p class='font-weight-bold text-warning'> ${tagInput.title} : ${tagInput.value}</p>`;
    }
    let { chonChucVu, luongCB } = staff;
    let salary = Number(chonChucVu) * Number(luongCB);
    let displayJT = (jT) => {
        if (jT == 1) {
            return 'Nhân viên';
        } else if (jT == 2) {
            return 'Quản lí';
        } else {
            return 'Giám đốc';
        }
    }
    rowContent += `<p class='font-weight-bold text-warning'>Chức vụ : ${displayJT(staff.chonChucVu)} </p>`;
    rowContent += `<p class='font-weight-bold text-warning'>Tổng lương : ${salary} </p>`;
    rowContent += `</p>`;
    document.getElementById("txtOutput").innerHTML = rowContent;
}

