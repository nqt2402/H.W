/** EX-1: QUẢN LÍ TUYỂN SINH */
function quanliTuyenSinh() {
    var diemChuanHD = parseFloat(document.getElementById("diemChuanHD").value);
    var diemMon1 = parseFloat(document.getElementById("diemMon1").value);
    var diemMon2 = parseFloat(document.getElementById("diemMon2").value);
    var diemMon3 = parseFloat(document.getElementById("diemMon3").value);
    var maKhuVucUuTien = document.getElementById("khuVucUutien").value;
    var diemKhuVucUuTien = kiemTraMaUuTien(maKhuVucUuTien);
    var maSoDoiTuongUuTien = parseFloat(document.getElementById("doiTuongUuTien").value);
    var diemDoiTuongUuTien = kiemTraMaSoDoiTuong(maSoDoiTuongUuTien);

    var tongDiem = diemMon1 + diemMon2 + diemMon3 + diemKhuVucUuTien + diemDoiTuongUuTien;

    function kiemTraMaUuTien(maKhuVucUuTien) {
        var diemKhuVucUuTien = 0;
        switch (maKhuVucUuTien) {
            case "X":
                diemKhuVucUuTien = 0;
                break;
            case "A":
                diemKhuVucUuTien = 2;
                break;
            case "B":
                diemKhuVucUuTien = 1;
                break;
            case "C":
                diemKhuVucUuTien = 0.5;
                break;
            default: console.log('Nhập lại mã khu vực ưu tiên');
        };
        return diemKhuVucUuTien;
    }

    function kiemTraMaSoDoiTuong(maSoDoiTuongUuTien) {
        var diemDoiTuongUuTien = 0;
        switch (maSoDoiTuongUuTien) {
            case 0:
                diemDoiTuongUuTien = 0;
                break;
            case 1:
                diemDoiTuongUuTien = 2.5;
                break;
            case 2:
                diemDoiTuongUuTien = 1.5;
                break;
            case 3:
                diemDoiTuongUuTien = 1;
                break;
            default: console.log('Nhập lại mã số đối tượng ưu tiên');
        }
        return diemDoiTuongUuTien;
    }
    console.log(diemKhuVucUuTien);
    console.log(diemDoiTuongUuTien);

    if ((tongDiem >= diemChuanHD) && (diemMon1 > 0 && diemMon2 > 0 && diemMon3 > 0)) {
        document.getElementById("txtTongDiem").innerHTML = "TỔNG ĐIỂM : " + tongDiem;
        document.getElementById("txtKetQua").innerHTML = "KẾT QUẢ : " + "Đậu";
    } else if ((tongDiem < diemChuanHD) || diemMon1 == 0 || diemMon2 == 0 || diemMon3 == 0) {
        document.getElementById("txtTongDiem").innerHTML = "TỔNG ĐIỂM : " + tongDiem;
        document.getElementById("txtKetQua").innerHTML = "KẾT QUẢ : " + "Rớt";
    } else {
        document.getElementById("txtTongDiem").innerHTML = "TỔNG ĐIỂM : " + tongDiem;
        document.getElementById("txtKetQua").innerHTML = "KẾT QUẢ : " + "Kiểm tra lại";
    }

}
document.getElementById("btnKetQua").addEventListener("click", quanliTuyenSinh);


/** EX-2: TÍNH TIỀN ĐIỆN */
function tinhTienDien() {
    const donGiaTienDien_Bac1 = 500;
    const donGiaTienDien_Bac2 = 650;
    const donGiaTienDien_Bac3 = 850;
    const donGiaTienDien_Bac4 = 1100;
    const donGiaTienDien_Bac5 = 1300;
    const soKWTieuThu_Bac1 = 50 - 0;
    const soKWTieuThu_Bac2 = 100 - 50;
    const soKWTieuThu_Bac3 = 200 - 100;
    const soKWTieuThu_Bac4 = 350 - 200;

    var soKWTieuThu_BacHienTai = parseFloat(document.getElementById("inputKW").value);
    var tongTienDien;

    if (soKWTieuThu_BacHienTai <= 50) {
        tongTienDien = soKWTieuThu_BacHienTai * donGiaTienDien_Bac1;
    } else if (50 < soKWTieuThu_BacHienTai && soKWTieuThu_BacHienTai <= 100) {
        tongTienDien = soKWTieuThu_Bac1 * donGiaTienDien_Bac1 + (soKWTieuThu_BacHienTai - 50) * donGiaTienDien_Bac2;
    } else if (100 < soKWTieuThu_BacHienTai && soKWTieuThu_BacHienTai <= 200) {
        tongTienDien = soKWTieuThu_Bac1 * donGiaTienDien_Bac1 + soKWTieuThu_Bac2 * donGiaTienDien_Bac2 + (soKWTieuThu_BacHienTai - 100) * donGiaTienDien_Bac3;
    } else if (200 < soKWTieuThu_BacHienTai && soKWTieuThu_BacHienTai <= 350) {
        tongTienDien = soKWTieuThu_Bac1 * donGiaTienDien_Bac1 + soKWTieuThu_Bac2 * donGiaTienDien_Bac2 + soKWTieuThu_Bac3 * donGiaTienDien_Bac3 + (soKWTieuThu_BacHienTai - 200) * donGiaTienDien_Bac4;
    } else if (350 < soKWTieuThu_BacHienTai) {
        tongTienDien = soKWTieuThu_Bac1 * donGiaTienDien_Bac1 + soKWTieuThu_Bac2 * donGiaTienDien_Bac2 + soKWTieuThu_Bac3 * donGiaTienDien_Bac3 + soKWTieuThu_Bac4 * donGiaTienDien_Bac4 + (soKWTieuThu_BacHienTai - 350) * donGiaTienDien_Bac5;
    } else { console.log("Kiểm tra lại"); }

    document.getElementById("txtTenKH").innerHTML = "Tên Khách hàng : " + document.getElementById("tenKH").value;
    document.getElementById("txtTienDien").innerHTML = "Số tiền điện phải trả : " + tongTienDien;
}
document.getElementById("btnTienDien").addEventListener("click", tinhTienDien);




