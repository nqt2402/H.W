/* VÒNG LẶP */
/* EX 1: */
function EX1__find_N() {

    // for (var n = 1; n < 10000; n++) {
    //     Sum += n;
    //     if (Sum > 10000) {
    //         console.log(n);
    //         break;
    //     }
    // }

    // WHILE LOOP
    var sumOfN = 0;
    var i = 0;

    while (i < 10000) {
        i++;
        sumOfN += i;
        if (sumOfN > 10000) {
            document.querySelector("#txtFindN").innerHTML = "Số nguyên dương n cần tìm là : " + i;
            break;
        }
    }
};
document.getElementById("btnFindN").addEventListener("click", EX1__find_N);

/* EX 2: */
function EX2__sumOfPow() {
    var sumOfPow = 0;
    var x = parseInt(document.querySelector("#inputX").value);
    var n = parseInt(document.querySelector("#inputN").value);

    for (var i = 1; i <= n; i++) {
        sumOfPow += Math.pow(x, i);
        document.querySelector("#txtSumOfPow").innerHTML = "Tổng S(n) = " + sumOfPow;
    }
}
document.querySelector("#btnSumOfPow").addEventListener("click", EX2__sumOfPow);

/* EX 3: */
function EX3__factorialOfN() {
    var ftr = 1;
    var n = parseInt(document.querySelector("#inputFactorialOfN").value);

    for (var i = 1; i <= n; i++) {
        ftr *= i;
        console.log(ftr);
        document.querySelector("#txtFactorialOfN").innerHTML = "Giai thừa của n: " + ftr;
    }
}
document.querySelector("#btnFactorialOfN").addEventListener("click",EX3__factorialOfN);

/* EX 4: */

function EX4__divCreation() {
    var content = "";

    for (var i = 1; i <= 10; i++) {
        if (i % 2 == 0) {
            content += "<br>" + "<div class='bg-danger text-white py-2'> Div chẵn " + i + " </div>";
            console.log(content);
        } else if (i % 2 == 1) {
            content += "<br>" + "<div class='bg-success text-white py-2'> Div lẻ " + i + " </div>";
            console.log(content);

        } else { console.log("Kiểm tra lại"); }
    }
    document.querySelector("#createDiv").innerHTML = content;
};
document.getElementById("btnDivCreation").addEventListener("click", EX4__divCreation);


